#!/bin/bash
#
# backup_full.sh - Backup comprimido de un directorio origen hacia un directorio destino.
# Uso: backup_full.sh <origen> <destino>

mostrar_ayuda() {
    cat << EOF
Uso: $(basename "$0") <origen> <destino>

Genera un backup comprimido (.tar.gz) del directorio <origen> y lo guarda en <destino>.
El archivo generado se nombra como: <nombre_origen>_bkp_<YYYYMMDD>.tar.gz

Argumentos:
  origen    Directorio a backupear (ej: /var/log)
  destino   Directorio donde se guarda el backup (ej: /backup_dir)

Opciones:
  -help     Muestra esta ayuda

Ejemplo:
  $(basename "$0") /var/log /backup_dir
EOF
}

if [[ "$1" == "-help" || "$1" == "--help" || -z "$1" || -z "$2" ]]; then
    mostrar_ayuda
    exit 0
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)

# Validar que el origen exista y su filesystem esté disponible
if [[ ! -d "$ORIGEN" ]] || ! df "$ORIGEN" >/dev/null 2>&1; then
    echo "Error: el origen '$ORIGEN' no existe o su sistema de archivos no está disponible." >&2
    exit 1
fi

# Validar que el destino exista y su filesystem esté disponible
if [[ ! -d "$DESTINO" ]] || ! df "$DESTINO" >/dev/null 2>&1; then
    echo "Error: el destino '$DESTINO' no existe o su sistema de archivos no está disponible." >&2
    exit 1
fi

NOMBRE_BASE=$(basename "$ORIGEN")
ARCHIVO_DESTINO="${DESTINO%/}/${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

tar -czf "$ARCHIVO_DESTINO" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE"

if [[ $? -eq 0 ]]; then
    echo "Backup creado exitosamente: $ARCHIVO_DESTINO"
    exit 0
else
    echo "Error: falló la creación del backup." >&2
    exit 1
fi
